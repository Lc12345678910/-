/**
 * AccessToken 缓存扩展
 */
package com.jfinal.weixin.sdk.cache;