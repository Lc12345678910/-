/**
 * 微信摇一摇周边 API
 */
package com.jfinal.weixin.sdk.api.shakearound;