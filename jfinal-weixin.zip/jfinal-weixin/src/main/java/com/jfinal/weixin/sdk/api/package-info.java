/**
 * 微信API接口
 */
package com.jfinal.weixin.sdk.api;