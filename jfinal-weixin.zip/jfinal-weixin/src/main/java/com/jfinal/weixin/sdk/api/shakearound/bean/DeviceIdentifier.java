package com.jfinal.weixin.sdk.api.shakearound.bean;

public class DeviceIdentifier {

    private Integer device_id;
    private String uuid;
    private Integer major;
    private Integer minor;

    public Integer getDevice_id() {
        return device_id;
    }
    public void setDevice_id(Integer device_id) {
        this.device_id = device_id;
    }
    public String getUuid() {
        return uuid;
    }
    public void setUuid(String uuid) {
        this.uuid = uuid;
    }
    public Integer getMajor() {
        return major;
    }
    public void setMajor(Integer major) {
        this.major = major;
    }
    public Integer getMinor() {
        return minor;
    }
    public void setMinor(Integer minor) {
        this.minor = minor;
    }
}
