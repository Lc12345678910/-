/**
 * api接口bean
 * @author L.cm
 *
 */
package com.jfinal.weixin.sdk.api.bean;