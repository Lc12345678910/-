/**
 * 微信智能硬件接口
 * 
 * 感谢：积淀的贡献
 * 
 * @author L.cm
 *
 */
package com.jfinal.weixin.iot;